package info.androidhive.navigationdrawer.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import info.androidhive.navigationdrawer.R;

public class HdmsActivity extends AppCompatActivity {

    WebView myWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hdms);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        myWebView = new WebView(getApplicationContext());
        setContentView(myWebView);
        myWebView.setWebViewClient(new WebViewClient());
        myWebView.loadUrl("http://hdms.iima.ac.in");
    }

    @Override
    public void onBackPressed() {
        if (myWebView.copyBackForwardList().getCurrentIndex() > 0) {
            myWebView.goBack();
        }
        else {
            // Your exit alert code, or alternatively line below to finish
            super.onBackPressed(); // finishes activity
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == android.R.id.home) {
            // finish the activity
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
